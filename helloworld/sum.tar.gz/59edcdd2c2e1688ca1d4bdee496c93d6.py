Python 3.12.0 (v3.12.0:0fb18b02c8, Oct  2 2023, 09:45:56) [Clang 13.0.0 (clang-1300.0.29.30)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> x = 3              # a whole number                   
... f = 3.1415926      # a floating point number              
... name = "Python"    # a string
... 
... print(x)
... print(f)
... print(name)
... 
... combination = name + " " + name
... print(combination)
... 
... sum = f + f
